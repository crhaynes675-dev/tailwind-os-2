"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const https = __importStar(require("https"));
const dynamo_1 = require("../lib/dynamo");
const response_1 = require("../lib/response");
const tenant_1 = require("../lib/tenant");
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY ?? '';
const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET ?? '';
const STRIPE_PRICE_ID = process.env.STRIPE_PRICE_ID ?? '';
function stripeRequest(method, path, data) {
    return new Promise((resolve, reject) => {
        const body = data ? new URLSearchParams(data).toString() : '';
        const req = https.request({
            hostname: 'api.stripe.com',
            path,
            method,
            headers: {
                'Authorization': `Bearer ${STRIPE_SECRET_KEY}`,
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength(body),
            },
        }, (res) => {
            let raw = '';
            res.on('data', (c) => raw += c);
            res.on('end', () => {
                try {
                    resolve(JSON.parse(raw));
                }
                catch {
                    resolve(raw);
                }
            });
        });
        req.on('error', reject);
        if (body)
            req.write(body);
        req.end();
    });
}
function tenantPk(tenantId) {
    return { PK: `TENANT_CONFIG#${tenantId}`, SK: 'CONFIG' };
}
const handler = async (event) => {
    try {
        const { httpMethod, path } = event;
        // POST /billing/webhook — Stripe event webhook (PUBLIC, no auth)
        if (httpMethod === 'POST' && path?.includes('/webhook')) {
            if (!STRIPE_SECRET_KEY)
                return (0, response_1.ok)({ received: true }, event);
            const payload = event.body ?? '';
            const sig = event.headers['stripe-signature'] || event.headers['Stripe-Signature'] || '';
            // Minimal timestamp-based replay protection (full HMAC requires crypto)
            const ts = sig.match(/t=(\d+)/)?.[1];
            if (ts && Math.abs(Date.now() / 1000 - parseInt(ts)) > 300) {
                return (0, response_1.badRequest)('Webhook timestamp too old', event);
            }
            const stripeEvent = JSON.parse(payload);
            const tenantId = stripeEvent.data?.object?.metadata?.tenantId ?? '';
            if (tenantId) {
                const subStatus = stripeEvent.data?.object?.status ?? '';
                const subId = stripeEvent.data?.object?.id ?? '';
                if (['customer.subscription.created', 'customer.subscription.updated', 'customer.subscription.deleted'].includes(stripeEvent.type)) {
                    await dynamo_1.ddb.send(new lib_dynamodb_1.UpdateCommand({
                        TableName: dynamo_1.TABLE,
                        Key: tenantPk(tenantId),
                        UpdateExpression: 'SET stripeSubscriptionId = :sid, stripeSubscriptionStatus = :ss, #plan = :plan, updatedAt = :now',
                        ExpressionAttributeNames: { '#plan': 'plan' },
                        ExpressionAttributeValues: {
                            ':sid': subId,
                            ':ss': subStatus,
                            ':plan': subStatus === 'active' ? 'starter' : 'trial',
                            ':now': new Date().toISOString(),
                        },
                    }));
                }
            }
            return (0, response_1.ok)({ received: true }, event);
        }
        // GET /billing/session — create Stripe customer portal session (authenticated)
        if (httpMethod === 'GET' && path?.includes('/session')) {
            if (!STRIPE_SECRET_KEY) {
                return (0, response_1.ok)({ url: null, message: 'Stripe not configured — add STRIPE_SECRET_KEY to Lambda env' }, event);
            }
            const tenantId = (0, tenant_1.getTenantId)(event);
            const tenantResult = await dynamo_1.ddb.send(new lib_dynamodb_1.GetCommand({
                TableName: dynamo_1.TABLE,
                Key: tenantPk(tenantId),
            }));
            if (!tenantResult.Item)
                return (0, response_1.notFound)('Tenant not found', event);
            let customerId = tenantResult.Item.stripeCustomerId;
            // Create Stripe customer if one doesn't exist yet
            if (!customerId) {
                const customer = await stripeRequest('POST', '/v1/customers', {
                    name: tenantResult.Item.companyName,
                    email: tenantResult.Item.adminEmail,
                    'metadata[tenantId]': tenantId,
                });
                customerId = customer.id;
                await dynamo_1.ddb.send(new lib_dynamodb_1.UpdateCommand({
                    TableName: dynamo_1.TABLE,
                    Key: tenantPk(tenantId),
                    UpdateExpression: 'SET stripeCustomerId = :cid, updatedAt = :now',
                    ExpressionAttributeValues: { ':cid': customerId, ':now': new Date().toISOString() },
                }));
            }
            // Create billing portal session
            const session = await stripeRequest('POST', '/v1/billing_portal/sessions', {
                customer: customerId,
                return_url: event.headers['origin'] || event.headers['Origin'] || 'https://d8im2hbxazf8r.cloudfront.net',
            });
            return (0, response_1.ok)({ url: session.url }, event);
        }
        // POST /billing/checkout — create Stripe checkout session for new subscription
        if (httpMethod === 'POST' && path?.includes('/checkout')) {
            if (!STRIPE_SECRET_KEY || !STRIPE_PRICE_ID) {
                return (0, response_1.ok)({ url: null, message: 'Stripe not configured' }, event);
            }
            const tenantId = (0, tenant_1.getTenantId)(event);
            const tenantResult = await dynamo_1.ddb.send(new lib_dynamodb_1.GetCommand({
                TableName: dynamo_1.TABLE,
                Key: tenantPk(tenantId),
            }));
            if (!tenantResult.Item)
                return (0, response_1.notFound)('Tenant not found', event);
            let customerId = tenantResult.Item.stripeCustomerId;
            if (!customerId) {
                const customer = await stripeRequest('POST', '/v1/customers', {
                    name: tenantResult.Item.companyName,
                    email: tenantResult.Item.adminEmail,
                    'metadata[tenantId]': tenantId,
                });
                customerId = customer.id;
                await dynamo_1.ddb.send(new lib_dynamodb_1.UpdateCommand({
                    TableName: dynamo_1.TABLE,
                    Key: tenantPk(tenantId),
                    UpdateExpression: 'SET stripeCustomerId = :cid, updatedAt = :now',
                    ExpressionAttributeValues: { ':cid': customerId, ':now': new Date().toISOString() },
                }));
            }
            const origin = event.headers['origin'] || event.headers['Origin'] || 'https://d8im2hbxazf8r.cloudfront.net';
            const session = await stripeRequest('POST', '/v1/checkout/sessions', {
                customer: customerId,
                'line_items[0][price]': STRIPE_PRICE_ID,
                'line_items[0][quantity]': '1',
                mode: 'subscription',
                success_url: `${origin}?billing=success`,
                cancel_url: `${origin}?billing=cancel`,
                'subscription_data[metadata][tenantId]': tenantId,
            });
            return (0, response_1.ok)({ url: session.url }, event);
        }
        return (0, response_1.badRequest)('Method not supported', event);
    }
    catch (err) {
        return (0, response_1.serverError)(err, event);
    }
};
exports.handler = handler;
//# sourceMappingURL=billing.js.map