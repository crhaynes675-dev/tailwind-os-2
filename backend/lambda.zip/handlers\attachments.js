"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_s3_1 = require("@aws-sdk/client-s3");
const s3_request_presigner_1 = require("@aws-sdk/s3-request-presigner");
const dynamo_1 = require("../lib/dynamo");
const response_1 = require("../lib/response");
const tenant_1 = require("../lib/tenant");
const crypto_1 = require("crypto");
const s3 = new client_s3_1.S3Client({ region: process.env.REGION ?? 'us-east-1' });
const BUCKET = process.env.ATTACHMENTS_BUCKET;
const handler = async (event) => {
    try {
        const t = (0, tenant_1.getTenantId)(event);
        const jobId = event.pathParameters?.jobId;
        if (!jobId)
            return (0, response_1.badRequest)('jobId is required');
        const body = JSON.parse(event.body ?? '{}');
        if (!body.filename || !body.contentType) {
            return (0, response_1.badRequest)('filename and contentType are required');
        }
        const attachId = (0, crypto_1.randomUUID)();
        const s3Key = `tenants/${t}/jobs/${jobId}/${attachId}/${body.filename}`;
        const now = new Date().toISOString();
        const username = event.requestContext.authorizer?.claims?.['cognito:username'] ?? 'unknown';
        const uploadUrl = await (0, s3_request_presigner_1.getSignedUrl)(s3, new client_s3_1.PutObjectCommand({ Bucket: BUCKET, Key: s3Key, ContentType: body.contentType }), { expiresIn: 300 });
        await dynamo_1.ddb.send(new lib_dynamodb_1.PutCommand({
            TableName: dynamo_1.TABLE,
            Item: {
                PK: (0, tenant_1.tpk)(t, 'JOB', jobId),
                SK: `ATTACH#${attachId}`,
                attachId, jobId, s3Key,
                filename: body.filename,
                contentType: body.contentType,
                uploadedBy: username,
                uploadedAt: now,
            },
        }));
        return (0, response_1.ok)({ attachId, uploadUrl, s3Key });
    }
    catch (err) {
        return (0, response_1.serverError)(err);
    }
};
exports.handler = handler;
//# sourceMappingURL=attachments.js.map