"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const dynamo_1 = require("../lib/dynamo");
const response_1 = require("../lib/response");
const tenant_1 = require("../lib/tenant");
const cognito = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({ region: process.env.REGION ?? 'us-east-1' });
const USER_POOL_ID = process.env.USER_POOL_ID;
function slugify(name) {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 24);
}
function tenantPk(tenantId) {
    return { PK: `TENANT_CONFIG#${tenantId}`, SK: 'CONFIG' };
}
const handler = async (event) => {
    try {
        const { httpMethod, path } = event;
        const isMe = path?.endsWith('/me');
        // GET /tenants/me — return current tenant config (authenticated)
        if (httpMethod === 'GET' && isMe) {
            const tenantId = (0, tenant_1.getTenantId)(event);
            const result = await dynamo_1.ddb.send(new lib_dynamodb_1.GetCommand({
                TableName: dynamo_1.TABLE,
                Key: tenantPk(tenantId),
            }));
            if (!result.Item)
                return (0, response_1.notFound)('Tenant not found');
            return (0, response_1.ok)(result.Item, event);
        }
        // POST /tenants — create a new company account (PUBLIC, no auth required)
        if (httpMethod === 'POST') {
            const body = JSON.parse(event.body ?? '{}');
            const { companyName, adminFirstName, adminLastName, adminEmail, adminUsername, password } = body;
            if (!companyName || !adminFirstName || !adminLastName || !adminEmail || !adminUsername || !password) {
                return (0, response_1.badRequest)('companyName, adminFirstName, adminLastName, adminEmail, adminUsername, and password are all required', event);
            }
            const tenantId = slugify(companyName) + '-' + Date.now().toString(36).slice(-4);
            const now = new Date().toISOString();
            const trialEndsAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
            // Create Cognito admin user for this tenant
            await cognito.send(new client_cognito_identity_provider_1.AdminCreateUserCommand({
                UserPoolId: USER_POOL_ID,
                Username: adminUsername,
                MessageAction: 'SUPPRESS',
                TemporaryPassword: password,
                UserAttributes: [
                    { Name: 'email', Value: adminEmail },
                    { Name: 'email_verified', Value: 'true' },
                    { Name: 'given_name', Value: adminFirstName },
                    { Name: 'family_name', Value: adminLastName },
                    { Name: 'custom:role', Value: 'admin' },
                    { Name: 'custom:tenantId', Value: tenantId },
                ],
            }));
            await cognito.send(new client_cognito_identity_provider_1.AdminSetUserPasswordCommand({
                UserPoolId: USER_POOL_ID,
                Username: adminUsername,
                Password: password,
                Permanent: true,
            }));
            // Create tenant config record in DynamoDB
            const tenantItem = {
                ...tenantPk(tenantId),
                GSI1PK: 'ALL_TENANTS',
                GSI1SK: `CREATED#${now}#${tenantId}`,
                tenantId,
                companyName,
                adminEmail,
                adminUsername,
                plan: 'trial',
                status: 'active',
                trialEndsAt,
                createdAt: now,
                updatedAt: now,
            };
            await dynamo_1.ddb.send(new lib_dynamodb_1.PutCommand({ TableName: dynamo_1.TABLE, Item: tenantItem }));
            return (0, response_1.created)({ tenantId, companyName, status: 'active', plan: 'trial', trialEndsAt }, event);
        }
        // PUT /tenants/me — update own tenant config (admin only)
        if (httpMethod === 'PUT' && isMe) {
            const claims = event.requestContext?.authorizer?.claims ?? {};
            if (claims['custom:role'] !== 'admin')
                return (0, response_1.forbidden)('Admin access required', event);
            const tenantId = (0, tenant_1.getTenantId)(event);
            const body = JSON.parse(event.body ?? '{}');
            const allowed = ['companyName'];
            const updates = Object.entries(body).filter(([k]) => allowed.includes(k));
            if (!updates.length)
                return (0, response_1.badRequest)('No updatable fields provided', event);
            const expr = updates.map(([k], i) => `#f${i} = :v${i}`).join(', ');
            const names = Object.fromEntries(updates.map(([k], i) => [`#f${i}`, k]));
            const values = Object.fromEntries(updates.map(([k, v], i) => [`:v${i}`, v]));
            values[':now'] = new Date().toISOString();
            names['#ua'] = 'updatedAt';
            await dynamo_1.ddb.send(new lib_dynamodb_1.UpdateCommand({
                TableName: dynamo_1.TABLE,
                Key: tenantPk(tenantId),
                UpdateExpression: `SET ${expr}, #ua = :now`,
                ExpressionAttributeNames: names,
                ExpressionAttributeValues: values,
                ConditionExpression: 'attribute_exists(PK)',
            }));
            return (0, response_1.ok)({ updated: true }, event);
        }
        return (0, response_1.badRequest)('Method not supported', event);
    }
    catch (err) {
        if (err.name === 'UsernameExistsException') {
            return (0, response_1.badRequest)('Username already exists', event);
        }
        if (err.name === 'InvalidPasswordException') {
            return (0, response_1.badRequest)('Password does not meet requirements: ' + err.message, event);
        }
        return (0, response_1.serverError)(err, event);
    }
};
exports.handler = handler;
//# sourceMappingURL=tenants.js.map