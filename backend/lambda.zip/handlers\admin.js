"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const dynamo_1 = require("../lib/dynamo");
const response_1 = require("../lib/response");
const cognito = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({ region: process.env.REGION ?? 'us-east-1' });
const USER_POOL_ID = process.env.USER_POOL_ID;
function isSuperAdmin(event) {
    const claims = event.requestContext?.authorizer?.claims ?? {};
    return claims['custom:role'] === 'super_admin';
}
const handler = async (event) => {
    try {
        if (!isSuperAdmin(event))
            return (0, response_1.forbidden)('Super admin access required', event);
        const { httpMethod, pathParameters } = event;
        const tenantId = pathParameters?.tenantId;
        // GET /admin/tenants — list all tenants
        if (httpMethod === 'GET' && !tenantId) {
            const result = await dynamo_1.ddb.send(new lib_dynamodb_1.QueryCommand({
                TableName: dynamo_1.TABLE,
                IndexName: 'GSI1',
                KeyConditionExpression: 'GSI1PK = :pk',
                ExpressionAttributeValues: { ':pk': 'ALL_TENANTS' },
                ScanIndexForward: false,
                Limit: 500,
            }));
            const tenants = result.Items ?? [];
            // Augment each tenant with user count from Cognito
            const augmented = await Promise.all(tenants.map(async (tenant) => {
                try {
                    const users = await cognito.send(new client_cognito_identity_provider_1.ListUsersCommand({
                        UserPoolId: USER_POOL_ID,
                        Filter: `"custom:tenantId" = "${tenant.tenantId}"`,
                        Limit: 60,
                    }));
                    return { ...tenant, userCount: users.Users?.length ?? 0 };
                }
                catch {
                    return { ...tenant, userCount: 0 };
                }
            }));
            return (0, response_1.ok)(augmented, event);
        }
        // PUT /admin/tenants/:tenantId — update tenant status or plan
        if (httpMethod === 'PUT' && tenantId) {
            const body = JSON.parse(event.body ?? '{}');
            const allowed = ['status', 'plan', 'companyName'];
            const updates = Object.entries(body).filter(([k]) => allowed.includes(k));
            if (!updates.length)
                return (0, response_1.badRequest)('No updatable fields provided', event);
            const expr = updates.map(([k], i) => `#f${i} = :v${i}`).join(', ');
            const names = Object.fromEntries(updates.map(([k], i) => [`#f${i}`, k]));
            const values = Object.fromEntries(updates.map(([k, v], i) => [`:v${i}`, v]));
            values[':now'] = new Date().toISOString();
            names['#ua'] = 'updatedAt';
            await dynamo_1.ddb.send(new lib_dynamodb_1.UpdateCommand({
                TableName: dynamo_1.TABLE,
                Key: { PK: `TENANT_CONFIG#${tenantId}`, SK: 'CONFIG' },
                UpdateExpression: `SET ${expr}, #ua = :now`,
                ExpressionAttributeNames: names,
                ExpressionAttributeValues: values,
                ConditionExpression: 'attribute_exists(PK)',
            }));
            return (0, response_1.ok)({ updated: true }, event);
        }
        // DELETE /admin/tenants/:tenantId — delete tenant config record
        if (httpMethod === 'DELETE' && tenantId) {
            await dynamo_1.ddb.send(new lib_dynamodb_1.DeleteCommand({
                TableName: dynamo_1.TABLE,
                Key: { PK: `TENANT_CONFIG#${tenantId}`, SK: 'CONFIG' },
            }));
            return (0, response_1.ok)({ deleted: true }, event);
        }
        return (0, response_1.badRequest)('Method not supported', event);
    }
    catch (err) {
        return (0, response_1.serverError)(err, event);
    }
};
exports.handler = handler;
//# sourceMappingURL=admin.js.map