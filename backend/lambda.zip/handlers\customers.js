"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamo_1 = require("../lib/dynamo");
const response_1 = require("../lib/response");
const tenant_1 = require("../lib/tenant");
const handler = async (event) => {
    try {
        const t = (0, tenant_1.getTenantId)(event);
        const { httpMethod, pathParameters } = event;
        const customerId = pathParameters?.customerId;
        if (httpMethod === 'GET') {
            const result = await dynamo_1.ddb.send(new lib_dynamodb_1.QueryCommand({
                TableName: dynamo_1.TABLE,
                IndexName: 'GSI1',
                KeyConditionExpression: 'GSI1PK = :pk',
                ExpressionAttributeValues: { ':pk': (0, tenant_1.tgsi)(t, 'CDB_RECORDS') },
                ScanIndexForward: false,
                Limit: 2000,
            }));
            return (0, response_1.ok)(result.Items ?? []);
        }
        if (httpMethod === 'POST') {
            const body = JSON.parse(event.body ?? '{}');
            const id = body.id || ('cdb_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7));
            const date = body.added || new Date().toISOString().slice(0, 10);
            const item = {
                PK: (0, tenant_1.tpk)(t, 'CDB', id), SK: 'RECORD',
                GSI1PK: (0, tenant_1.tgsi)(t, 'CDB_RECORDS'),
                GSI1SK: `ADDED#${date}#${id}`,
                ...body, id, added: date,
                createdAt: new Date().toISOString(),
            };
            await dynamo_1.ddb.send(new lib_dynamodb_1.PutCommand({ TableName: dynamo_1.TABLE, Item: item }));
            return (0, response_1.ok)({ id });
        }
        if (!customerId)
            return (0, response_1.badRequest)('customerId is required');
        if (httpMethod === 'PUT') {
            const body = JSON.parse(event.body ?? '{}');
            const date = body.added || new Date().toISOString().slice(0, 10);
            const item = {
                PK: (0, tenant_1.tpk)(t, 'CDB', customerId), SK: 'RECORD',
                GSI1PK: (0, tenant_1.tgsi)(t, 'CDB_RECORDS'),
                GSI1SK: `ADDED#${date}#${customerId}`,
                ...body, id: customerId,
                updatedAt: new Date().toISOString(),
            };
            await dynamo_1.ddb.send(new lib_dynamodb_1.PutCommand({ TableName: dynamo_1.TABLE, Item: item }));
            return (0, response_1.ok)({ saved: true });
        }
        if (httpMethod === 'DELETE') {
            await dynamo_1.ddb.send(new lib_dynamodb_1.DeleteCommand({
                TableName: dynamo_1.TABLE,
                Key: { PK: (0, tenant_1.tpk)(t, 'CDB', customerId), SK: 'RECORD' },
            }));
            return (0, response_1.ok)({ deleted: true });
        }
        return (0, response_1.badRequest)('Method not supported');
    }
    catch (err) {
        return (0, response_1.serverError)(err);
    }
};
exports.handler = handler;
//# sourceMappingURL=customers.js.map