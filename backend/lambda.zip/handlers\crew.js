"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamo_1 = require("../lib/dynamo");
const response_1 = require("../lib/response");
const tenant_1 = require("../lib/tenant");
const handler = async (event) => {
    try {
        const t = (0, tenant_1.getTenantId)(event);
        const { httpMethod, pathParameters } = event;
        const crewId = pathParameters?.crewId;
        if (httpMethod === 'GET') {
            const result = await dynamo_1.ddb.send(new lib_dynamodb_1.QueryCommand({
                TableName: dynamo_1.TABLE,
                IndexName: 'GSI1',
                KeyConditionExpression: 'GSI1PK = :pk',
                ExpressionAttributeValues: { ':pk': (0, tenant_1.tgsi)(t, 'CREW_ROSTER') },
                Limit: 500,
            }));
            return (0, response_1.ok)(result.Items ?? []);
        }
        if (httpMethod === 'POST') {
            const body = JSON.parse(event.body ?? '{}');
            const id = body.id || ('cr_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7));
            const name = body.name || 'Unknown';
            const item = {
                PK: (0, tenant_1.tpk)(t, 'CREW', id), SK: 'MEMBER',
                GSI1PK: (0, tenant_1.tgsi)(t, 'CREW_ROSTER'),
                GSI1SK: `NAME#${name}#${id}`,
                ...body, id,
                createdAt: new Date().toISOString(),
            };
            await dynamo_1.ddb.send(new lib_dynamodb_1.PutCommand({ TableName: dynamo_1.TABLE, Item: item }));
            return (0, response_1.ok)({ id });
        }
        if (!crewId)
            return (0, response_1.badRequest)('crewId is required');
        if (httpMethod === 'PUT') {
            const body = JSON.parse(event.body ?? '{}');
            const name = body.name || 'Unknown';
            const item = {
                PK: (0, tenant_1.tpk)(t, 'CREW', crewId), SK: 'MEMBER',
                GSI1PK: (0, tenant_1.tgsi)(t, 'CREW_ROSTER'),
                GSI1SK: `NAME#${name}#${crewId}`,
                ...body, id: crewId,
                updatedAt: new Date().toISOString(),
            };
            await dynamo_1.ddb.send(new lib_dynamodb_1.PutCommand({ TableName: dynamo_1.TABLE, Item: item }));
            return (0, response_1.ok)({ saved: true });
        }
        if (httpMethod === 'DELETE') {
            await dynamo_1.ddb.send(new lib_dynamodb_1.DeleteCommand({
                TableName: dynamo_1.TABLE,
                Key: { PK: (0, tenant_1.tpk)(t, 'CREW', crewId), SK: 'MEMBER' },
            }));
            return (0, response_1.ok)({ deleted: true });
        }
        return (0, response_1.badRequest)('Method not supported');
    }
    catch (err) {
        return (0, response_1.serverError)(err);
    }
};
exports.handler = handler;
//# sourceMappingURL=crew.js.map