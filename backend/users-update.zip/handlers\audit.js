"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamo_1 = require("../lib/dynamo");
const response_1 = require("../lib/response");
const handler = async (event) => {
    try {
        const jobId = event.pathParameters?.jobId;
        if (!jobId)
            return (0, response_1.badRequest)('jobId is required');
        const limit = parseInt(event.queryStringParameters?.limit ?? '50', 10);
        const result = await dynamo_1.ddb.send(new lib_dynamodb_1.QueryCommand({
            TableName: dynamo_1.TABLE,
            KeyConditionExpression: 'PK = :pk AND begins_with(SK, :prefix)',
            ExpressionAttributeValues: {
                ':pk': `JOB#${jobId}`,
                ':prefix': 'AUDIT#',
            },
            ScanIndexForward: false, // newest first
            Limit: Math.min(limit, 200),
        }));
        return (0, response_1.ok)(result.Items ?? []);
    }
    catch (err) {
        return (0, response_1.serverError)(err);
    }
};
exports.handler = handler;
//# sourceMappingURL=audit.js.map