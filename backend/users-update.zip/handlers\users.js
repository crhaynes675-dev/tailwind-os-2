"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const response_1 = require("../lib/response");
const cognito = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({ region: process.env.REGION ?? 'us-east-1' });
const USER_POOL_ID = process.env.USER_POOL_ID;
const handler = async (event) => {
    try {
        const claims = event.requestContext?.authorizer?.claims ?? {};
        const isAdmin = claims['custom:role'] === 'admin';
        const { httpMethod } = event;
        const username = event.pathParameters?.username;
        const isPasswordPath = event.path?.endsWith('/password') ?? false;
        // GET /users — list all Cognito users (any authenticated user — needed for crew roster)
        if (httpMethod === 'GET') {
            const result = await cognito.send(new client_cognito_identity_provider_1.ListUsersCommand({
                UserPoolId: USER_POOL_ID,
                Limit: 60,
            }));
            const users = (result.Users ?? []).map(u => {
                const attrs = {};
                (u.Attributes ?? []).forEach(a => { if (a.Name && a.Value)
                    attrs[a.Name] = a.Value; });
                return {
                    username: u.Username ?? '',
                    email: attrs['email'] ?? '',
                    givenName: attrs['given_name'] ?? '',
                    familyName: attrs['family_name'] ?? '',
                    role: attrs['custom:role'] ?? 'user',
                    status: u.UserStatus ?? '',
                    enabled: u.Enabled ?? true,
                };
            });
            return (0, response_1.ok)(users, event);
        }
        // POST /users — create a new user in Cognito (admin only)
        if (httpMethod === 'POST' && !username) {
            if (!isAdmin)
                return (0, response_1.forbidden)('Admin access required', event);
            const body = JSON.parse(event.body ?? '{}');
            const { username: newUsername, email, givenName, familyName, password, role } = body;
            if (!newUsername || !email || !givenName || !familyName || !password) {
                return (0, response_1.badRequest)('username, email, givenName, familyName, and password are all required', event);
            }
            await cognito.send(new client_cognito_identity_provider_1.AdminCreateUserCommand({
                UserPoolId: USER_POOL_ID,
                Username: newUsername,
                MessageAction: 'SUPPRESS',
                TemporaryPassword: password,
                UserAttributes: [
                    { Name: 'email', Value: email },
                    { Name: 'email_verified', Value: 'true' },
                    { Name: 'given_name', Value: givenName },
                    { Name: 'family_name', Value: familyName },
                    { Name: 'custom:role', Value: role ?? 'user' },
                ],
            }));
            // Make the password permanent so the user doesn't have to reset on first login
            await cognito.send(new client_cognito_identity_provider_1.AdminSetUserPasswordCommand({
                UserPoolId: USER_POOL_ID,
                Username: newUsername,
                Password: password,
                Permanent: true,
            }));
            return (0, response_1.created)({ username: newUsername, created: true }, event);
        }
        if (!username)
            return (0, response_1.badRequest)('username is required', event);
        // PUT /users/{username}/password — set a new permanent password (admin only)
        if (httpMethod === 'PUT' && isPasswordPath) {
            if (!isAdmin)
                return (0, response_1.forbidden)('Admin access required', event);
            const body = JSON.parse(event.body ?? '{}');
            const { password } = body;
            if (!password)
                return (0, response_1.badRequest)('password is required', event);
            await cognito.send(new client_cognito_identity_provider_1.AdminSetUserPasswordCommand({
                UserPoolId: USER_POOL_ID,
                Username: username,
                Password: password,
                Permanent: true,
            }));
            return (0, response_1.ok)({ updated: true }, event);
        }
        // DELETE /users/{username} — remove user from Cognito (admin only)
        if (httpMethod === 'DELETE') {
            if (!isAdmin)
                return (0, response_1.forbidden)('Admin access required', event);
            await cognito.send(new client_cognito_identity_provider_1.AdminDeleteUserCommand({
                UserPoolId: USER_POOL_ID,
                Username: username,
            }));
            return (0, response_1.noContent)(event);
        }
        return (0, response_1.badRequest)('Method not supported', event);
    }
    catch (err) {
        if (err.name === 'UsernameExistsException') {
            return (0, response_1.badRequest)('Username already exists', event);
        }
        if (err.name === 'InvalidPasswordException') {
            return (0, response_1.badRequest)('Password does not meet requirements: ' + err.message, event);
        }
        if (err.name === 'UserNotFoundException') {
            return (0, response_1.notFound)('User not found', event);
        }
        return (0, response_1.serverError)(err, event);
    }
};
exports.handler = handler;
//# sourceMappingURL=users.js.map