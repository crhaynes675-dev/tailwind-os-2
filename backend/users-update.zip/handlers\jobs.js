"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamo_1 = require("../lib/dynamo");
const response_1 = require("../lib/response");
const crypto_1 = require("crypto");
function jobKey(jobId) {
    return { PK: `JOB#${jobId}`, SK: 'METADATA' };
}
function callerUsername(event) {
    return event.requestContext.authorizer?.claims?.['cognito:username'] ?? 'unknown';
}
const handler = async (event) => {
    try {
        const { httpMethod, pathParameters, queryStringParameters } = event;
        const jobId = pathParameters?.jobId;
        // GET /jobs — list all jobs, optional ?from=YYYY-MM-DD&to=YYYY-MM-DD
        if (httpMethod === 'GET' && !jobId) {
            const from = queryStringParameters?.from ?? '0000-00-00';
            const to = queryStringParameters?.to ?? '9999-99-99';
            const result = await dynamo_1.ddb.send(new lib_dynamodb_1.QueryCommand({
                TableName: dynamo_1.TABLE,
                IndexName: 'GSI1',
                KeyConditionExpression: 'GSI1PK = :pk AND GSI1SK BETWEEN :from AND :to',
                ExpressionAttributeValues: {
                    ':pk': 'JOBS',
                    ':from': `DATE#${from}`,
                    ':to': `DATE#${to}#~`,
                },
            }));
            return (0, response_1.ok)(result.Items ?? []);
        }
        // GET /jobs/:jobId — full job detail (metadata + all sub-items)
        if (httpMethod === 'GET' && jobId) {
            const result = await dynamo_1.ddb.send(new lib_dynamodb_1.QueryCommand({
                TableName: dynamo_1.TABLE,
                KeyConditionExpression: 'PK = :pk',
                ExpressionAttributeValues: { ':pk': `JOB#${jobId}` },
            }));
            if (!result.Items?.length)
                return (0, response_1.notFound)();
            const meta = result.Items.find(i => i.SK === 'METADATA');
            const units = result.Items.filter(i => i.SK.startsWith('UNIT#'));
            return (0, response_1.ok)({ ...meta, units });
        }
        // POST /jobs — create a new job
        if (httpMethod === 'POST' && !jobId) {
            const body = JSON.parse(event.body ?? '{}');
            if (!body.jobName)
                return (0, response_1.badRequest)('jobName is required');
            const id = (0, crypto_1.randomUUID)();
            const now = new Date().toISOString();
            const date = (body.scheduledDate ?? now.slice(0, 10));
            const item = {
                PK: `JOB#${id}`,
                SK: 'METADATA',
                GSI1PK: 'JOBS',
                GSI1SK: `DATE#${date}#${id}`,
                GSI2PK: body.assignedTo ? `USER#${body.assignedTo}` : undefined,
                GSI2SK: body.assignedTo ? `DATE#${date}#${id}` : undefined,
                jobId: id,
                jobName: body.jobName,
                address: body.address ?? '',
                scheduledDate: date,
                assignedTo: body.assignedTo ?? '',
                status: body.status ?? 'scheduled',
                notes: body.notes ?? '',
                quoteNum: body.quoteNum ?? '',
                createdBy: callerUsername(event),
                createdAt: now,
                updatedAt: now,
            };
            await dynamo_1.ddb.send(new lib_dynamodb_1.PutCommand({ TableName: dynamo_1.TABLE, Item: item }));
            // Write initial audit entry
            await dynamo_1.ddb.send(new lib_dynamodb_1.PutCommand({
                TableName: dynamo_1.TABLE,
                Item: {
                    PK: `JOB#${id}`,
                    SK: `AUDIT#${now}#${(0, crypto_1.randomUUID)()}`,
                    action: 'created',
                    user: callerUsername(event),
                    ts: now,
                },
            }));
            return (0, response_1.created)(item);
        }
        // PUT /jobs/:jobId — update job
        if (httpMethod === 'PUT' && jobId) {
            const body = JSON.parse(event.body ?? '{}');
            const now = new Date().toISOString();
            const allowed = ['jobName', 'address', 'scheduledDate', 'assignedTo', 'status', 'notes', 'quoteNum'];
            const updates = Object.entries(body).filter(([k]) => allowed.includes(k));
            if (!updates.length)
                return (0, response_1.badRequest)('No valid fields to update');
            const expr = updates.map(([k], i) => `#f${i} = :v${i}`).join(', ');
            const names = Object.fromEntries(updates.map(([k], i) => [`#f${i}`, k]));
            const values = Object.fromEntries(updates.map(([k, v], i) => [`:v${i}`, v]));
            values[':now'] = now;
            names['#ua'] = 'updatedAt';
            await dynamo_1.ddb.send(new lib_dynamodb_1.UpdateCommand({
                TableName: dynamo_1.TABLE,
                Key: jobKey(jobId),
                UpdateExpression: `SET ${expr}, #ua = :now`,
                ExpressionAttributeNames: names,
                ExpressionAttributeValues: values,
                ConditionExpression: 'attribute_exists(PK)',
            }));
            await dynamo_1.ddb.send(new lib_dynamodb_1.PutCommand({
                TableName: dynamo_1.TABLE,
                Item: {
                    PK: `JOB#${jobId}`,
                    SK: `AUDIT#${now}#${(0, crypto_1.randomUUID)()}`,
                    action: 'updated',
                    user: callerUsername(event),
                    changes: Object.fromEntries(updates),
                    ts: now,
                },
            }));
            return (0, response_1.ok)({ jobId, updated: true });
        }
        // DELETE /jobs/:jobId — delete job and all sub-items
        if (httpMethod === 'DELETE' && jobId) {
            const existing = await dynamo_1.ddb.send(new lib_dynamodb_1.QueryCommand({
                TableName: dynamo_1.TABLE,
                KeyConditionExpression: 'PK = :pk',
                ExpressionAttributeValues: { ':pk': `JOB#${jobId}` },
                ProjectionExpression: 'PK, SK',
            }));
            const items = existing.Items ?? [];
            if (!items.length)
                return (0, response_1.notFound)();
            // DynamoDB batch delete in chunks of 25
            for (let i = 0; i < items.length; i += 25) {
                await dynamo_1.ddb.send(new lib_dynamodb_1.BatchWriteCommand({
                    RequestItems: {
                        [dynamo_1.TABLE]: items.slice(i, i + 25).map(item => ({
                            DeleteRequest: { Key: { PK: item.PK, SK: item.SK } },
                        })),
                    },
                }));
            }
            return (0, response_1.noContent)();
        }
        return (0, response_1.badRequest)('Method not supported');
    }
    catch (err) {
        return (0, response_1.serverError)(err);
    }
};
exports.handler = handler;
//# sourceMappingURL=jobs.js.map