"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamo_1 = require("../lib/dynamo");
const response_1 = require("../lib/response");
// Stores the calculator form snapshot (fields + unit rows) keyed by a formId
// (typically the EJN / external job number, or a client-generated UUID).
// PK: FORM#<formId>   SK: SNAPSHOT
const handler = async (event) => {
    try {
        const { httpMethod, pathParameters } = event;
        const formId = pathParameters?.formId;
        if (!formId)
            return (0, response_1.badRequest)('formId is required');
        if (httpMethod === 'GET') {
            const result = await dynamo_1.ddb.send(new lib_dynamodb_1.GetCommand({
                TableName: dynamo_1.TABLE,
                Key: { PK: `FORM#${formId}`, SK: 'SNAPSHOT' },
            }));
            if (!result.Item)
                return (0, response_1.notFound)('Form not found');
            return (0, response_1.ok)(result.Item);
        }
        if (httpMethod === 'PUT') {
            const body = JSON.parse(event.body ?? '{}');
            const item = {
                PK: `FORM#${formId}`,
                SK: 'SNAPSHOT',
                formId,
                fields: body.fields ?? {},
                unitRows: body.unitRows ?? [],
                dlVisible: body.dlVisible ?? false,
                updatedAt: new Date().toISOString(),
            };
            await dynamo_1.ddb.send(new lib_dynamodb_1.PutCommand({ TableName: dynamo_1.TABLE, Item: item }));
            return (0, response_1.ok)({ saved: true });
        }
        return (0, response_1.badRequest)('Method not supported');
    }
    catch (err) {
        return (0, response_1.serverError)(err);
    }
};
exports.handler = handler;
//# sourceMappingURL=forms.js.map