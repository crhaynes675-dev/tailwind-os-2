"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamo_1 = require("../lib/dynamo");
const response_1 = require("../lib/response");
// SMS queue / notification log
// PK: SMS#<id>  SK: MESSAGE
// GSI1PK: SMS_QUEUE  GSI1SK: CREATED#<ts>#<id>
const handler = async (event) => {
    try {
        const { httpMethod, pathParameters } = event;
        const messageId = pathParameters?.messageId;
        if (httpMethod === 'GET') {
            const result = await dynamo_1.ddb.send(new lib_dynamodb_1.QueryCommand({
                TableName: dynamo_1.TABLE,
                IndexName: 'GSI1',
                KeyConditionExpression: 'GSI1PK = :pk',
                ExpressionAttributeValues: { ':pk': 'SMS_QUEUE' },
                ScanIndexForward: false,
                Limit: 200,
            }));
            return (0, response_1.ok)(result.Items ?? []);
        }
        if (httpMethod === 'POST') {
            const body = JSON.parse(event.body ?? '{}');
            const id = body.id || ('sms_' + Date.now());
            const ts = body.created || new Date().toISOString();
            const item = {
                PK: `SMS#${id}`, SK: 'MESSAGE',
                GSI1PK: 'SMS_QUEUE',
                GSI1SK: `CREATED#${ts}#${id}`,
                ...body,
                id,
                created: ts,
            };
            await dynamo_1.ddb.send(new lib_dynamodb_1.PutCommand({ TableName: dynamo_1.TABLE, Item: item }));
            return (0, response_1.ok)({ id });
        }
        if (!messageId)
            return (0, response_1.badRequest)('messageId is required');
        if (httpMethod === 'PUT') {
            const body = JSON.parse(event.body ?? '{}');
            const ts = body.created || new Date().toISOString();
            const item = {
                PK: `SMS#${messageId}`, SK: 'MESSAGE',
                GSI1PK: 'SMS_QUEUE',
                GSI1SK: `CREATED#${ts}#${messageId}`,
                ...body,
                id: messageId,
                updatedAt: new Date().toISOString(),
            };
            await dynamo_1.ddb.send(new lib_dynamodb_1.PutCommand({ TableName: dynamo_1.TABLE, Item: item }));
            return (0, response_1.ok)({ saved: true });
        }
        return (0, response_1.badRequest)('Method not supported');
    }
    catch (err) {
        return (0, response_1.serverError)(err);
    }
};
exports.handler = handler;
//# sourceMappingURL=sms.js.map