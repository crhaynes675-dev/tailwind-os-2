"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamo_1 = require("../lib/dynamo");
const response_1 = require("../lib/response");
// New Customer Intake records
// PK: NCI#<id>  SK: RECORD
// GSI1PK: NCI_RECORDS  GSI1SK: DATE#<date>#<id>
const handler = async (event) => {
    try {
        const { httpMethod, pathParameters } = event;
        const recordId = pathParameters?.recordId;
        if (httpMethod === 'GET') {
            const result = await dynamo_1.ddb.send(new lib_dynamodb_1.QueryCommand({
                TableName: dynamo_1.TABLE,
                IndexName: 'GSI1',
                KeyConditionExpression: 'GSI1PK = :pk',
                ExpressionAttributeValues: { ':pk': 'NCI_RECORDS' },
                ScanIndexForward: false,
                Limit: 1000,
            }));
            return (0, response_1.ok)(result.Items ?? []);
        }
        if (httpMethod === 'POST') {
            const body = JSON.parse(event.body ?? '{}');
            const id = body.id || ('nci_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7));
            const date = body.date || new Date().toISOString().slice(0, 10);
            const item = {
                PK: `NCI#${id}`, SK: 'RECORD',
                GSI1PK: 'NCI_RECORDS',
                GSI1SK: `DATE#${date}#${id}`,
                ...body,
                id,
                createdAt: new Date().toISOString(),
            };
            await dynamo_1.ddb.send(new lib_dynamodb_1.PutCommand({ TableName: dynamo_1.TABLE, Item: item }));
            return (0, response_1.ok)({ id });
        }
        if (!recordId)
            return (0, response_1.badRequest)('recordId is required');
        if (httpMethod === 'PUT') {
            const body = JSON.parse(event.body ?? '{}');
            const date = body.date || new Date().toISOString().slice(0, 10);
            const item = {
                PK: `NCI#${recordId}`, SK: 'RECORD',
                GSI1PK: 'NCI_RECORDS',
                GSI1SK: `DATE#${date}#${recordId}`,
                ...body,
                id: recordId,
                updatedAt: new Date().toISOString(),
            };
            await dynamo_1.ddb.send(new lib_dynamodb_1.PutCommand({ TableName: dynamo_1.TABLE, Item: item }));
            return (0, response_1.ok)({ saved: true });
        }
        if (httpMethod === 'DELETE') {
            await dynamo_1.ddb.send(new lib_dynamodb_1.DeleteCommand({
                TableName: dynamo_1.TABLE,
                Key: { PK: `NCI#${recordId}`, SK: 'RECORD' },
            }));
            return (0, response_1.ok)({ deleted: true });
        }
        return (0, response_1.badRequest)('Method not supported');
    }
    catch (err) {
        return (0, response_1.serverError)(err);
    }
};
exports.handler = handler;
//# sourceMappingURL=nci.js.map