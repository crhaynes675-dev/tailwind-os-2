"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamo_1 = require("../lib/dynamo");
const response_1 = require("../lib/response");
const crypto_1 = require("crypto");
function callerUsername(event) {
    return event.requestContext.authorizer?.claims?.['cognito:username'] ?? 'unknown';
}
const handler = async (event) => {
    try {
        const { httpMethod, pathParameters } = event;
        const jobId = pathParameters?.jobId;
        const piwrId = pathParameters?.piwrId;
        if (!jobId)
            return (0, response_1.badRequest)('jobId is required');
        // GET /jobs/:jobId/piwr — list all PIWR rows for a job
        if (httpMethod === 'GET') {
            const result = await dynamo_1.ddb.send(new lib_dynamodb_1.QueryCommand({
                TableName: dynamo_1.TABLE,
                KeyConditionExpression: 'PK = :pk AND begins_with(SK, :prefix)',
                ExpressionAttributeValues: {
                    ':pk': `JOB#${jobId}`,
                    ':prefix': 'PIWR#',
                },
            }));
            return (0, response_1.ok)(result.Items ?? []);
        }
        // POST /jobs/:jobId/piwr — add a PIWR row
        if (httpMethod === 'POST') {
            const body = JSON.parse(event.body ?? '{}');
            const id = (0, crypto_1.randomUUID)();
            const now = new Date().toISOString();
            const item = {
                PK: `JOB#${jobId}`,
                SK: `PIWR#${id}`,
                piwrId: id,
                jobId,
                lineId: body.lineId ?? '',
                frameSize: body.frameSize ?? '',
                roughOpening: body.roughOpening ?? '',
                type: body.type ?? '',
                vendor: body.vendor ?? '',
                shims: body.shims ?? '',
                glass: body.glass ?? '',
                mullCovers: body.mullCovers ?? '',
                dripCap: body.dripCap ?? '',
                operates: body.operates ?? '',
                damage: body.damage ?? '',
                nailFins: body.nailFins ?? '',
                notes: body.notes ?? '',
                createdBy: callerUsername(event),
                createdAt: now,
                updatedAt: now,
            };
            await dynamo_1.ddb.send(new lib_dynamodb_1.PutCommand({ TableName: dynamo_1.TABLE, Item: item }));
            return (0, response_1.created)(item);
        }
        // PUT /jobs/:jobId/piwr/:piwrId — update a PIWR row
        if (httpMethod === 'PUT' && piwrId) {
            const body = JSON.parse(event.body ?? '{}');
            const now = new Date().toISOString();
            const fields = ['shims', 'glass', 'mullCovers', 'dripCap', 'operates', 'damage', 'nailFins', 'notes', 'lineId', 'frameSize', 'roughOpening', 'type', 'vendor'];
            const updates = Object.entries(body).filter(([k]) => fields.includes(k));
            if (!updates.length)
                return (0, response_1.badRequest)('No valid fields to update');
            const expr = updates.map(([k], i) => `#f${i} = :v${i}`).join(', ');
            const names = Object.fromEntries(updates.map(([k], i) => [`#f${i}`, k]));
            const values = Object.fromEntries(updates.map(([k, v], i) => [`:v${i}`, v]));
            values[':now'] = now;
            names['#ua'] = 'updatedAt';
            await dynamo_1.ddb.send(new lib_dynamodb_1.UpdateCommand({
                TableName: dynamo_1.TABLE,
                Key: { PK: `JOB#${jobId}`, SK: `PIWR#${piwrId}` },
                UpdateExpression: `SET ${expr}, #ua = :now`,
                ExpressionAttributeNames: names,
                ExpressionAttributeValues: values,
                ConditionExpression: 'attribute_exists(PK)',
            }));
            return (0, response_1.ok)({ piwrId, updated: true });
        }
        // DELETE /jobs/:jobId/piwr/:piwrId
        if (httpMethod === 'DELETE' && piwrId) {
            await dynamo_1.ddb.send(new lib_dynamodb_1.DeleteCommand({
                TableName: dynamo_1.TABLE,
                Key: { PK: `JOB#${jobId}`, SK: `PIWR#${piwrId}` },
                ConditionExpression: 'attribute_exists(PK)',
            }));
            return (0, response_1.noContent)();
        }
        return (0, response_1.badRequest)('Method not supported');
    }
    catch (err) {
        return (0, response_1.serverError)(err);
    }
};
exports.handler = handler;
//# sourceMappingURL=piwr.js.map