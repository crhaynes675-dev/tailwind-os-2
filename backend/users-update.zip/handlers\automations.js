"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamo_1 = require("../lib/dynamo");
const response_1 = require("../lib/response");
// Automation rules
// PK: AUTO#<id>  SK: RULE
// GSI1PK: AUTO_RULES  GSI1SK: CREATED#<ts>#<id>
const handler = async (event) => {
    try {
        const { httpMethod, pathParameters } = event;
        const ruleId = pathParameters?.ruleId;
        if (httpMethod === 'GET') {
            const result = await dynamo_1.ddb.send(new lib_dynamodb_1.QueryCommand({
                TableName: dynamo_1.TABLE,
                IndexName: 'GSI1',
                KeyConditionExpression: 'GSI1PK = :pk',
                ExpressionAttributeValues: { ':pk': 'AUTO_RULES' },
                ScanIndexForward: false,
                Limit: 500,
            }));
            return (0, response_1.ok)(result.Items ?? []);
        }
        if (httpMethod === 'POST') {
            const body = JSON.parse(event.body ?? '{}');
            const id = body.id || ('ar_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7));
            const created = body.created || new Date().toISOString();
            const item = {
                PK: `AUTO#${id}`, SK: 'RULE',
                GSI1PK: 'AUTO_RULES',
                GSI1SK: `CREATED#${created}#${id}`,
                ...body,
                id,
                created,
            };
            await dynamo_1.ddb.send(new lib_dynamodb_1.PutCommand({ TableName: dynamo_1.TABLE, Item: item }));
            return (0, response_1.ok)({ id });
        }
        if (!ruleId)
            return (0, response_1.badRequest)('ruleId is required');
        if (httpMethod === 'PUT') {
            const body = JSON.parse(event.body ?? '{}');
            const created = body.created || new Date().toISOString();
            const item = {
                PK: `AUTO#${ruleId}`, SK: 'RULE',
                GSI1PK: 'AUTO_RULES',
                GSI1SK: `CREATED#${created}#${ruleId}`,
                ...body,
                id: ruleId,
                updatedAt: new Date().toISOString(),
            };
            await dynamo_1.ddb.send(new lib_dynamodb_1.PutCommand({ TableName: dynamo_1.TABLE, Item: item }));
            return (0, response_1.ok)({ saved: true });
        }
        if (httpMethod === 'DELETE') {
            await dynamo_1.ddb.send(new lib_dynamodb_1.DeleteCommand({
                TableName: dynamo_1.TABLE,
                Key: { PK: `AUTO#${ruleId}`, SK: 'RULE' },
            }));
            return (0, response_1.ok)({ deleted: true });
        }
        return (0, response_1.badRequest)('Method not supported');
    }
    catch (err) {
        return (0, response_1.serverError)(err);
    }
};
exports.handler = handler;
//# sourceMappingURL=automations.js.map